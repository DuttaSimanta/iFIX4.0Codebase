package fileutils

import (
    "testing"
)

func TestReadPropertiesFile(t *testing.T) {
	
    props, err := ReadPropertiesFile(`E:\goworkdone\src\config\application.properties`)
    if err != nil {
        t.Error("Error while reading properties file")
	}
	if props["PORT"] != "9000"{
		t.Error("Error properties not loaded correctly")
	}

}